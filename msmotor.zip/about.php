<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>About - MSMOTOR</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
 

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-none d-lg-block">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
       <i class="icofont-envelope"></i><a href="mailto:singh@msmotor.in">pritam@msmotor.in, singh@msmotor.in</a>
         <a href="#"><i class="icofont-phone"> </i>+919416024795,+919982224545</a>
      </div>
      <div class="social-links">
       <a href="#" class="twitter"><i class="icofont-twitter" title="Twitter"></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
   <header id="header">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>
      </div>
   <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li class="drop-down"><a href="about.php">About Us</a>
            <ul>
              <li><a href="ls.php">Leadership</a></li>
              <li ><a href="achievement.php">Achievement</a></li>
             
            </ul>
          </li>
         
         
          <li class="drop-down"><a href="#">Product</a>
            <ul>
              <li><a href="product-ap.php">Automotive paint</a></li>
              <li ><a href="product-ab.php">Abrissive</a></li>
              <li ><a href="product-cv.php">Transportation Coatings for Commercial Vehicles</a></li>
              <li ><a href="product-rb.php">Refinish Business
</a></li>
             
              <li ><a href="product-rt.php">Reflective tapes</a></li>
              <li ><a href="product-pu.php">3M PU Sealant & Double Side Tape </a></li>
              
             
            </ul>
          </li>
          <li><a href="career.php">Career</a></li>
          <li><a href="contact.php">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header>
  
  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <div id="inner_banner" class="section inner_banner_section">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="title-holder">
            <div class="title-holder-cell text-left">
              <h1 class="page-title">About Us</h1>
              <ol class="breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li class="active">About Us</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><!-- End Breadcrumbs -->

    <!-- ======= About Us Section ======= -->
      <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">
		 <div class="section-title" data-aos="fade-up">
          <span>About Us</span>
          <h2>About Us</h2>
		  </div>
          
        <div class="row justify-content-end">
          <div class="col-lg-11">
            <div class="row justify-content-end">

              <div class=" col-md-4 d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="icofont-simple-smile"></i>
                  <span data-toggle="counter-up">277</span>
                  <p>Happy Clients</p>
                </div>
              </div>

             

              <div class="col-md-4  d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="icofont-clock-time"></i>
                  <span data-toggle="counter-up">32</span>
                  <p>Years of experience</p>
                </div>
              </div>

              <div class="col-md-4  d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="icofont-award"></i>
                  <span data-toggle="counter-up">10</span>
                  <p>Awards</p>
                </div>
              </div>

            </div>
          </div>
        </div>

        <div class="row">

          <div class="col-lg-6 video-box align-self-baseline" data-aos="zoom-in" data-aos-delay="100">
           	<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
			  <div class="carousel-inner">
				<div class="carousel-item active">
				  <img class="d-block w-100" src="assets/img/demo.jpg" alt="First slide">
				</div>
				<div class="carousel-item">
				  <img class="d-block w-100" src="assets/img/demo.jpg" alt="Second slide">
				</div>
				<div class="carousel-item">
				  <img class="d-block w-100" src="assets/img/demo.jpg" alt="Third slide">
				</div>
			  </div>
			</div>
          </div>

          <div class="col-lg-6 pt-3 pt-lg-0 content">
            <h3>M.S Motor was established in 16 Aug 1988 under the entrepreneurship of Mr.Pritam Singh. It began as a small unit in Ambala City.</h3>
            <p class="font-italic">
               MS Motors Group (with 2 Sister Concerns) is a ______proprieter__organisation.  . Not just confined to paints which is 90 percent of the main business area;  These products range from different varieties and can be customised on customers’ needs. 
				

            </p>
            <ul>
              <li><i class="bx bx-check-double"></i> It is a leading distributor of automotive paints in North India.</li>
              <li><i class="bx bx-check-double"></i> Its diverse portfolio includes an extensive range of automotive paints ranging from major industrial and commercial vehicle business to refinishing business</li>
              <li><i class="bx bx-check-double"></i> the firm supplies other products supplementary to bus body building and commercial vehicle & passenger vehicle business.</li>
              <li><i class="bx bx-check-double"></i> The business is extended to various states in India such as Rajasthan, Punjab, Haryana, Jharkhand, Uttar Pradesh & Madhya Pradesh.</li>
              <li><i class="bx bx-check-double"></i> M.S Motor was the first organisation to start apply and supply services in India.</li>
            </ul>
            <p>
              M.S Motor was the first organisation to start apply and supply services in India. Its cost
				cutting guarantee with quality increasing strategy made it pioneer in its field. It also led to
				per unit cost supply to its clients.
            </p>
          </div>

        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= About Boxes Section ======= -->
    <section id="about-boxes" class="about-boxes">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch card-hover" data-aos="fade-up" data-aos-delay="100">
            <div class="card">
              <img src="assets/img/about-boxes-1.png" class="card-img-top" alt="...">
              <div class="card-icon">
                <i class="icofont-focus"></i>
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="">Our Mission</a></h5>
                <p class="card-text">M.S Motor is proud to say that it deals with major automobile MNCs like Mercedes Benz, Ashoka Leyland, Tata Motors, Scania, Eicher Volvo and that 90 percent of the paint supplied to them is of Axalta which is our major supplier. Through 3m India Ltd we launched metal to metal Sealant which is now doing most of the Indian market. </p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch card-hover2" data-aos="fade-up" data-aos-delay="200">
            <div class="card">
              <img src="assets/img/about-boxes-2.png" class="card-img-top" alt="...">
              <div class="card-icon">
                <i class="icofont-eye "></i>
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="">Our Vision</a></h5>
                <p class="card-text">M.S Motor was the first organisation to start apply and supply services in India. Its cost cutting guarantee with quality increasing strategy made it pioneer in its field. It also led to per unit cost supply to its clients. Our major suppliers are Axalta Coatings Systems, 3M IATD (Industrial Adhesive and Tape Division), 3M ASD (Abrasive System Division).  </p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch card-hover3" data-aos="fade-up" data-aos-delay="300">
            <div class="card">
              <img src="assets/img/about-boxes-3.png" class="card-img-top" alt="...">
              <div class="card-icon">
                <i class="icofont-mega-phone"></i>
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="">Our Moto</a></h5>
                <p class="card-text">We believe in complete vertical integration and command over every aspect of our business - to deliver products of impeccable quality every time. We are focused to serve the industries by setting standards of quality, value, services and commitment to customers.  </p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

        <section id="features" class="features">
      <div class="container" data-aos="fade-up">
		<div class="section-title" data-aos="fade-up">
          <span>Sister Concerns Company’s</span>
          <h2><b>Sister Concerns Company’s</b></h2>
          <p></p>
        </div>
        <ul class="nav nav-tabs row d-flex">
          <li class="nav-item col-3">
            <a class="nav-link active show" data-toggle="tab" href="#tab-1">
              <i class="ri-gps-line"></i>
              <h4 class="d-none d-lg-block">Satguru Enterprises</h4>
            </a>
          </li>
          <li class="nav-item col-3">
            <a class="nav-link" data-toggle="tab" href="#tab-2">
              <i class="ri-body-scan-line"></i>
              <h4 class="d-none d-lg-block">Prem Auto Pvt.Ltd</h4>
            </a>
          </li>
			
         
         
        </ul>

         <div class="tab-content">
          <div class="tab-pane active show" id="tab-1">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <br/><h3>Satguru Enterprises</h3>
                <p class="font-italic">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                  magna aliqua.
                </p>
                <ul>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                  <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate trideta storacalaperda mastiro dolore eu fugiat nulla pariatur.</li>
                </ul>
                <p>
                  Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                  velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                  culpa qui officia deserunt mollit anim id est laborum
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="assets/img/features-1.png" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-2">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <br/><h3>Prem Auto Pvt.Ltd</h3>
                <p>
                  Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                  velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                  culpa qui officia deserunt mollit anim id est laborum
                </p>
                <p class="font-italic">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                  magna aliqua.
                </p>
                <ul>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                  <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
                  <li><i class="ri-check-double-line"></i> Provident mollitia neque rerum asperiores dolores quos qui a. Ipsum neque dolor voluptate nisi sed.</li>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate trideta storacalaperda mastiro dolore eu fugiat nulla pariatur.</li>
                </ul>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="assets/img/features-2.png" alt="" class="img-fluid">
              </div>
            </div>
          </div>
         

      </div>
         

      </div>
    </section><!-- End Features Section -->
    <!-- ======= Our Skills Section ======= -->
   

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include 'footer.php';?>

</body>

</html>