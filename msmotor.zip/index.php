	<?php  
		        include 'conn.php';?>
				
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>MSMOTOR - Index</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
 

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

 <style>

   

    
</style>
 
</head>

<body>

  
  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="">
  
    <div class="container d-flex">
      <div class="contact-info mr-auto">
       <i class="icofont-envelope"></i><a href="mailto:singh@msmotor.in">pritam@msmotor.in, singh@msmotor.in</a>
         <a href="#"><i class="icofont-phone"> </i>+919416024795,+919982224545</a>
      </div>
      <div class="social-links">
        <a href="#" class="twitter"><i class="icofont-twitter" title="Twitter"></i></a>
        <a href="#" class="facebook"><i class="icofont-facebook" title="Facebook"></i></a>
        <a href="#" class="instagram"><i class="icofont-instagram" title="Instagram"></i></a>
        <a href="#" class="skype"><i class="icofont-skype" title="Skype"></i></a>
        <a href="#" class="linkedin"><i class="icofont-linkedin" title="Linkedin"></i></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li class="drop-down"><a href="about.php">About Us</a>
            <ul>
              <li><a href="ls.php">Leadership</a></li>
              <li ><a href="achievement.php">Achievement</a></li>
             
            </ul>
          </li>
         
         
          <li class="drop-down"><a href="#">Product</a>
            <ul>
              <li><a href="product-ap.php">Automotive paint</a></li>
              <li ><a href="product-ab.php">Abrissive</a></li>
              <li ><a href="product-cv.php">Transportation Coatings for Commercial Vehicles</a></li>
              <li ><a href="product-rb.php">Refinish Business
</a></li>
             
              <li ><a href="product-rt.php">Reflective tapes</a></li>
              <li ><a href="product-pu.php">3M PU Sealant & Double Side Tape </a></li>
              
             
            </ul>
          </li>
          <li><a href="career.php">Career</a></li>
          <li><a href="contact.php">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
       

       	<?php  
		       
                $query = "SELECT * FROM images ORDER BY id DESC";  
                $result = mysqli_query($conn, $query);  
				$i=0;
                while($row = mysqli_fetch_array($result))  
                {  
			     if($i==0){
					 echo '<div class="carousel-item active">' ;
					  echo ' <img class="d-block w-100" src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'"  alt=""  />';
					  echo '</div>';
				 }
				 else{
					echo '<div class="carousel-item" > ';
                     echo ' <img class="d-block w-100" src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'"  alt=""  />'; 
					echo '</div>';
				}
					$i=$i+1;
				}
				
                ?>  
          
          
      

        <!-- Slide 3 -->
       

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon bx bx-left-arrow" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon bx bx-right-arrow" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

    </div>
  </section><!-- End Hero -->

  <main id="main">
	
     
     <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">
		 <div class="section-title" data-aos="fade-up">
          <span>About Us</span>
          <h2>About Us</h2>
		  </div>
          
        <div class="row justify-content-end">
          <div class="col-lg-11">
            <div class="row justify-content-end">

              <div class=" col-md-4 d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="icofont-simple-smile"></i>
                  <span data-toggle="counter-up">277</span>
                  <p>Happy Clients</p>
                </div>
              </div>

             

              <div class="col-md-4  d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="icofont-clock-time"></i>
                  <span data-toggle="counter-up">32</span>
                  <p>Years of experience</p>
                </div>
              </div>

              <div class="col-md-4  d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="icofont-award"></i>
                  <span data-toggle="counter-up">10</span>
                  <p>Awards</p>
                </div>
              </div>

            </div>
          </div>
        </div>

        <div class="row">

          <div class="col-lg-6 video-box align-self-baseline" data-aos="zoom-in" data-aos-delay="100">
           	<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
			  <div class="carousel-inner">
				<div class="carousel-item active">
				  <img class="d-block w-100" src="assets/img/demo.jpg" alt="First slide">
				</div>
				<div class="carousel-item">
				  <img class="d-block w-100" src="assets/img/demo.jpg" alt="Second slide">
				</div>
				<div class="carousel-item">
				  <img class="d-block w-100" src="assets/img/demo.jpg" alt="Third slide">
				</div>
			  </div>
			</div>
          </div>

          <div class="col-lg-6 pt-3 pt-lg-0 content">
            <h3>M.S Motor was established in 16 Aug 1988 under the entrepreneurship of Mr.Pritam Singh. It began as a small unit in Ambala City.</h3>
            <p class="font-italic">
               MS Motors Group (with 2 Sister Concerns) is a ______proprieter__organisation.  . Not just confined to paints which is 90 percent of the main business area;  These products range from different varieties and can be customised on customers’ needs. 
				

            </p>
            <ul>
              <li><i class="bx bx-check-double"></i> It is a leading distributor of automotive paints in North India.</li>
              <li><i class="bx bx-check-double"></i> Its diverse portfolio includes an extensive range of automotive paints ranging from major industrial and commercial vehicle business to refinishing business</li>
              <li><i class="bx bx-check-double"></i> the firm supplies other products supplementary to bus body building and commercial vehicle & passenger vehicle business.</li>
              <li><i class="bx bx-check-double"></i> The business is extended to various states in India such as Rajasthan, Punjab, Haryana, Jharkhand, Uttar Pradesh & Madhya Pradesh.</li>
              <li><i class="bx bx-check-double"></i> M.S Motor was the first organisation to start apply and supply services in India.</li>
            </ul>
            <p>
              M.S Motor was the first organisation to start apply and supply services in India. Its cost
				cutting guarantee with quality increasing strategy made it pioneer in its field. It also led to
				per unit cost supply to its clients.
            </p>
          </div>

        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= About Boxes Section ======= -->
    <section id="about-boxes" class="about-boxes">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch card-hover" data-aos="fade-up" data-aos-delay="100">
            <div class="card">
              <img src="assets/img/about-boxes-1.png" class="card-img-top" alt="...">
              <div class="card-icon">
                <i class="icofont-focus"></i>
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="">Our Mission</a></h5>
                <p class="card-text">M.S Motor is proud to say that it deals with major automobile MNCs like Mercedes Benz, Ashoka Leyland, Tata Motors, Scania, Eicher Volvo and that 90 percent of the paint supplied to them is of Axalta which is our major supplier. Through 3m India Ltd we launched metal to metal Sealant which is now doing most of the Indian market. </p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch card-hover2" data-aos="fade-up" data-aos-delay="200">
            <div class="card">
              <img src="assets/img/about-boxes-2.png" class="card-img-top" alt="...">
              <div class="card-icon">
                <i class="icofont-eye "></i>
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="">Our Vision</a></h5>
                <p class="card-text">M.S Motor was the first organisation to start apply and supply services in India. Its cost cutting guarantee with quality increasing strategy made it pioneer in its field. It also led to per unit cost supply to its clients. Our major suppliers are Axalta Coatings Systems, 3M IATD (Industrial Adhesive and Tape Division), 3M ASD (Abrasive System Division).  </p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch card-hover3" data-aos="fade-up" data-aos-delay="300">
            <div class="card">
              <img src="assets/img/about-boxes-3.png" class="card-img-top" alt="...">
              <div class="card-icon">
                <i class="icofont-mega-phone"></i>
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="">Our Moto</a></h5>
                <p class="card-text">We believe in complete vertical integration and command over every aspect of our business - to deliver products of impeccable quality every time. We are focused to serve the industries by setting standards of quality, value, services and commitment to customers.  </p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Boxes Section -->

    </section><!-- End Cta Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">
		 <div class="section-title" data-aos="fade-up">
          <span>Products</span>
          <h2>Products</h2>
          
        </div>
        
                
                    <!---->
                  
           
		
        <div class="row">
		   
		 <?php  
		        
                $query = "SELECT * FROM service ORDER BY id DESC";  
                $result = mysqli_query($conn, $query);  
					
                while($row = mysqli_fetch_array($result))  
                {  
					echo '<div class="col-md-4  services1 center-block"> ';
					echo '<div class="section-box-three"> ';
					echo '<figure>';
					echo '<h3>"'.$row['head'].'"</h3>';
					
					 echo ' <p>"'.$row['para'].'" </p>'; 
					echo '<a href="'.$row['link'].'" class="btn btn-read">Read More</a>  ';
					echo '</figure>';
					echo '<img src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'" class="img-responsive" alt=""  />';
					echo '</div> ';
					echo '</div> ';
					
				}  
				
                ?>  
          

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Portfolio Section ======= -->
  <!-- End Portfolio Section -->

    <!-- ======= Our Clients Section ======= -->
    <section id="clients" class="clients">
      <div class="container aos-init aos-animate" data-aos="zoom-in">

       
		<div class="section-title" data-aos="fade-up">
          <span>Our Clients</span>
          <h2>Our Clients</h2>
          
        </div>
          

       
        <div class="row">

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/client-1.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/client-2.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/client-3.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/client-4.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/client-5.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/client-6.png" class="img-fluid" alt="">
          </div>

        </div>

      </div>
    

        </div>

      </div>
    </section><!-- End Our Clients Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include 'footer.php';?>

</body>

</html>