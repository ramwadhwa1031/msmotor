<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>About - MSMOTOR</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
 

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-none d-lg-block">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
       <i class="icofont-envelope"></i><a href="mailto:singh@msmotor.in">pritam@msmotor.in, singh@msmotor.in</a>
         <a href="#"><i class="icofont-phone"> </i>+919416024795,+919982224545</a>
      </div>
      <div class="social-links">
       <a href="#" class="twitter"><i class="icofont-twitter" title="Twitter"></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
   <header id="header">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>
      </div>

       <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li class="drop-down"><a href="about.php">About Us</a>
            <ul>
              <li><a href="ls.php">Leadership</a></li>
              <li ><a href="achievement.php">Achievement</a></li>
             
            </ul>
          </li>
         
         
          <li class="drop-down"><a href="#">Product</a>
            <ul>
              <li><a href="product-ap.php">Automotive paint</a></li>
              <li ><a href="product-ab.php">Abrissive</a></li>
              <li ><a href="product-cv.php">Transportation Coatings for Commercial Vehicles</a></li>
              <li ><a href="product-rb.php">Refinish Business
</a></li>
             
              <li ><a href="product-rt.php">Reflective tapes</a></li>
              <li ><a href="product-pu.php">3M PU Sealant & Double Side Tape </a></li>
              
             
            </ul>
          </li>
          <li><a href="career.php">Career</a></li>
          <li><a href="contact.php">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header>
  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
     <div id="inner_banner" class="section inner_banner_section">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="title-holder">
            <div class="title-holder-cell text-left">
              <h1 class="page-title">Awards</h1>
              <ol class="breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li class="active">Awards</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><<!-- End Breadcrumbs -->

    <!-- ======= Features Section ======= -->
    <section id="features" class="features section-bg">
      <div class="container">
		 <div class="section-title" data-aos="fade-up">
          <span>Awards</span>
          <h2>Awards</h2>
          
        </div>

        <div class="row content">
          <div class="col-md-5" data-aos="fade-right">
            <img src="assets/img/features-1.svg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-4" data-aos="fade-left">
            <h3>2007- 3M – Outstanding performance in sales and collection at the Grand Prix Program.</h3>
           
           
          </div>
        </div>

        <div class="row content">
          <div class="col-md-5 order-1 order-md-2" data-aos="fade-left">
            <img src="assets/img/features-2.svg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 order-2 order-md-1" data-aos="fade-right">
            <h3>2011- 3M – Approved distributor of abrasive products of 3M India Limited </h3>
           
          </div>
        </div>

        <div class="row content">
          <div class="col-md-5" data-aos="fade-right">
            <img src="assets/img/features-3.svg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5" data-aos="fade-left">
            <h3>2014- 3M – In recognition of your contribution towards driving business in vehicle body builder segment (Traffic Safety & Security Division)
</h3>
           
          </div>
        </div>

        <div class="row content">
          <div class="col-md-5 order-1 order-md-2" data-aos="fade-left">
            <img src="assets/img/features-2.svg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 order-2 order-md-1" data-aos="fade-right">
            <h3>2015-3M- Authorised distributor of 3M Industrial adhesive and tapes division.
 </h3>
           
          </div>
        </div>
		<div class="row content">
          <div class="col-md-5" data-aos="fade-right">
            <img src="assets/img/features-3.svg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5" data-aos="fade-left">
            <h3>2016- Award for support to Axalta

</h3>
           
          </div>
        </div>
		<div class="row content">
          <div class="col-md-5 order-1 order-md-2" data-aos="fade-left">
            <img src="assets/img/features-2.svg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 order-2 order-md-1" data-aos="fade-right">
            <h3>2017- Esdee paints- For continued satisfactory Operation of the organisation’s Management system.

 </h3>
           
          </div>
        </div>

      </div>
    </section><!-- End Features Section -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
 <?php include 'footer.php';?>

</body>

</html>