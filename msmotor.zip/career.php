<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Contact - MSMOTOR</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
 

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-none d-lg-block">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
       <i class="icofont-envelope"></i><a href="mailto:singh@msmotor.in">pritam@msmotor.in, singh@msmotor.in</a>
         <a href="#"><i class="icofont-phone"> </i>+919416024795,+919982224545</a>
      </div>
      <div class="social-links">
       <a href="#" class="twitter"><i class="icofont-twitter" title="Twitter"></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
   <header id="header">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>
      </div>

         <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li class="drop-down"><a href="about.php">About Us</a>
            <ul>
              <li><a href="ls.php">Leadership</a></li>
              <li ><a href="achievement.php">Achievement</a></li>
             
            </ul>
          </li>
         
         
          <li class="drop-down"><a href="#">Product</a>
            <ul>
              <li><a href="product-ap.php">Automotive paint</a></li>
              <li ><a href="product-ab.php">Abrissive</a></li>
              <li ><a href="product-cv.php">Transportation Coatings for Commercial Vehicles</a></li>
              <li ><a href="product-rb.php">Refinish Business
</a></li>
             
              <li ><a href="product-rt.php">Reflective tapes</a></li>
              <li ><a href="product-pu.php">3M PU Sealant & Double Side Tape </a></li>
              
             
            </ul>
          </li>
          <li><a href="career.php">Career</a></li>
          <li><a href="contact.php">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
     <div id="inner_banner" class="section inner_banner_section">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="title-holder">
            <div class="title-holder-cell text-left">
              <h1 class="page-title">Career</h1>
              <ol class="breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li class="active">Career</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><!-- End Breadcrumbs -->

    <!-- ======= Contact Section ======= -->
  

    <section id="contact" class="contact">
       <div class="container" data-aos="fade-up">
		 <div class="section-title" data-aos="fade-up">
          <span>Career</span>
          <h2>Career</h2>
		<p>We are a dynamically developing company with successes on the market. As a family company we are far from anonymity and rigid hierarchical structures. We offer work among goal-oriented people who derive joy and satisfaction from achieving those goals and we offer our employees the opportunity to self-develop.</p>
        <p>On receipt of an interview call on behalf of MS Motors, the candidate may take necessary measures such as visiting the official MS Motors website to get the details verified or reach out to the concerned authorities in the Human Resources (HR) department.

The MS Motor is committed to a policy of equal opportunity. Our policy aims to ensure that no job applicant or employee receives less favourable treatment on the grounds of sex, marital status, race, colour, creed, ethnic origin, sexual orientation, age or disability.
</p>
		<div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-lg-10">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="form-row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required />
                  <div class="validate"></div>
                </div>
                <div class="col-md-6 form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email"  required/>
                  <div class="validate"></div>
                </div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Contact No." data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" required />
                <div class="validate"></div>
              </div>
			  <div class="form-row">
                <div class="col-md-6 form-group">
                  <input type="file" name="file" class="form-control"  required />
                  <div class="validate"></div>
                </div>
                <div class="col-md-6 form-group">
                  <input type="number" class="form-control" name="experience" id="experience" placeholder="experience"  required/>
                  <div class="validate"></div>
                </div>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                <div class="validate"></div>
              </div>
              <div class="mb-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Submit </button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <?php include 'footer.php';?>

</body>

</html>