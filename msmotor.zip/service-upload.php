<html>
<head>
</head>

<body>
<form action="data1.php" method="post" enctype="multipart/form-data">
    <label>Select Image File:</label>
	<input type="text" name="head">
	<input type="text" name="para">
	
	
    <input type="file" name="image">
	<input type="text" name="link">
    <input type="submit" name="submit" value="Upload">
</form>
</body>
</html>