<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>About - MSMOTOR</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
 

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-none d-lg-block">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
       <i class="icofont-envelope"></i><a href="mailto:singh@msmotor.in">pritam@msmotor.in, singh@msmotor.in</a>
         <a href="#"><i class="icofont-phone"> </i>+919416024795,+919982224545</a>
      </div>
      <div class="social-links">
       <a href="#" class="twitter"><i class="icofont-twitter" title="Twitter"></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
   <header id="header">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>
      </div>

       <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li class="drop-down"><a href="about.php">About Us</a>
            <ul>
              <li><a href="ls.php">Leadership</a></li>
              <li ><a href="achievement.php">Achievement</a></li>
             
            </ul>
          </li>
         
         
          <li class="drop-down"><a href="#">Product</a>
            <ul>
              <li><a href="product-ap.php">Automotive paint</a></li>
              <li ><a href="product-ab.php">Abrissive</a></li>
              <li ><a href="product-cv.php">Transportation Coatings for Commercial Vehicles</a></li>
              <li ><a href="product-rb.php">Refinish Business
</a></li>
             
              <li ><a href="product-rt.php">Reflective tapes</a></li>
              <li ><a href="product-pu.php">3M PU Sealant & Double Side Tape </a></li>
              
             
            </ul>
          </li>
          <li><a href="career.php">Career</a></li>
          <li><a href="contact.php">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header>
  
  <main id="main">
	 <div id="inner_banner" class="section inner_banner_section">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="title-holder">
            <div class="title-holder-cell text-left">
              <h1 class="page-title">Transportation Coatings for Commercial Vehicles</h1>
              <ol class="breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li class="active">Transportation Coatings for Commercial Vehicles</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
    <!-- ======= Breadcrumbs ======= -->
    <><!-- End Breadcrumbs -->

    <!-- ======= About Us Section ======= -->
    <section id="services" class="services">
      <div class="container">
	<div class="section-title" data-aos="fade-up">
          <span>Coatings for Commercial Vehicles
</span>
          <h2>Coatings for Commercial Vehicles
</h2>
       </div>
	<div class="product">
        <div class="row">
		
          <div class="col-lg-6 ">
            <div class="product_content mt-5 mt-lg-0" data-aos="fade-up">
             
             
              <p>One of the main business area of M.S Motor is providing paint to vehicle body builder segment in Commercial Vehicle business. We provide transportation coating systems for original equipment manufacturers of buses, containers and trailers. The major vehicle body builders who undertake projects from government like STU (State Transport Undertaking) buses, school buses, and airport tarmac coach and in private market like tourist coaches, school buses are supplied paint by us. 
M.S Motor was the first organisation to start apply and supply services in India. Its cost cutting guarantee with quality increasing strategy made it pioneer in its field of commercial vehicle. It also led to per unit cost service to its clients in respect to assurance of vehicles cost.
</p>
            </div>
            
            
            
          </div>
          <div class="image col-lg-6 "  data-aos="fade-left" data-aos-delay="100">
			<div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">
			   <div class="carousel-inner" role="listbox">
				<?php  
		        include 'conn.php';
                $query = "SELECT * FROM product where kind ='Transportation Coatings for Commercial Vehicles'";  
                $result = mysqli_query($conn, $query);  
				$i=0;
                while($row = mysqli_fetch_array($result))  
                {  
			     if($i==0){
					 echo '<div class="carousel-item active">' ;
					  echo ' <img class="d-block w-100" src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'"  alt=""  />';
					  echo '</div>';
				 }
				 else{
					echo '<div class="carousel-item" > ';
                     echo ' <img class="d-block w-100" src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'"  alt=""  />'; 
					echo '</div>';
				}
					$i=$i+1;
				}
				
                ?>  
				 <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
      
        <span class="sr-only">Previous</span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
        
        <span class="sr-only">Next</span>
      </a>

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>
				  
			  </div>
		  
		  </div>
        </div>

      </div>
    </section>

    <!-- ======= Our Skills Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container">

        <div class="row">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-Hopper">Hopper</li>
              <li data-filter=".filter-Tata-Tipper">Tata Tipper</li>
              <li data-filter=".filter-Tata-Containers">Tata Containers</li>
              <li data-filter=".filter-DHL-Container">DHL Container</li>
              <li data-filter=".filter-Patanjali-Container">Patanjali Container</li>
              <li data-filter=".filter-Tata-307">Tata 307</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container "  data-aos="fade-up" data-aos-delay="100">

		   
		 <?php  
		        include 'conn.php';
                $query = "SELECT * FROM proimg where product='COATINGS FOR COMMERCIAL VEHICLES'";  
                $result = mysqli_query($conn, $query);  
					
                while($row = mysqli_fetch_array($result))  
                {  
					echo '<div class="col-lg-4 col-md-6 portfolio-item  filter-'.$row['kind'].'"   > ';
					echo '<div class="portfolio-wrap"> ';
					echo '<img src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'" class="img-responsive" alt=""  />';
					echo ' <div class="portfolio-info">';
					echo '<h4><strong>"'.$row['kind'].'"</strong></h4>';
					echo ' <div class="portfolio-links">';
					echo '<a href="data:image/jpeg;base64,'.base64_encode($row['image'] ).'" data-gall="portfolioGallery" class="venobox" title="App 1"><i class="bx bx-plus"></i></a>'; 
				
					
					echo '</div> ';
					echo '</div> ';
					echo '</div> ';
					echo '</div> ';
					
				}  
				
                ?>  
				

          

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include 'footer.php';?>

</body>

</html>