		 <?php  
		        include 'conn.php';
                $query = "SELECT * FROM gallery ORDER BY id DESC";  
                $result = mysqli_query($db, $query);  
					
                while($row = mysqli_fetch_array($result))  
                {  
					echo '<a href= "data:image/jpeg;base64,'.base64_encode($row['image'] ).'"</h3>';
					
				}  
				
                ?>  
	</div