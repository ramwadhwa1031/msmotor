<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Contact - MSMOTOR</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
 

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <style>
  .box-shadow-hover:hover {
	  
 
  box-shadow: 0 5px 15px rgba(145, 92, 182, .4);
  
}

.pointer {
  cursor: pointer;
}

img {
  width: auto;
  max-height: 100px;
}
  </style>
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-none d-lg-block">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
       <i class="icofont-envelope"></i><a href="mailto:singh@msmotor.in">pritam@msmotor.in, singh@msmotor.in</a>
         <a href="#"><i class="icofont-phone"> </i>+919416024795,+919982224545</a>
      </div>
      <div class="social-links">
       <a href="#" class="twitter"><i class="icofont-twitter" title="Twitter"></i></a>
      </div>
    </div>
  </section>

   <header id="header">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>
      </div>

         <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li class="drop-down"><a href="about.php">About Us</a>
            <ul>
              <li><a href="ls.php">Leadership</a></li>
              <li ><a href="achievement.php">Achievement</a></li>
             
            </ul>
          </li>
         
         
          <li class="drop-down"><a href="#">Product</a>
            <ul>
              <li><a href="product-ap.php">Automotive paint</a></li>
              <li ><a href="product-ab.php">Abrissive</a></li>
              <li ><a href="product-cv.php">Transportation Coatings for Commercial Vehicles</a></li>
              <li ><a href="product-rb.php">Refinish Business
</a></li>
             
              <li ><a href="product-rt.php">Reflective tapes</a></li>
              <li ><a href="product-pu.php">3M PU Sealant & Double Side Tape </a></li>
              
             
            </ul>
          </li>
          <li><a href="career.php">Career</a></li>
          <li><a href="contact.php">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header>
  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
     <div id="inner_banner" class="section inner_banner_section">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="title-holder">
            <div class="title-holder-cell text-left">
              <h1 class="page-title">Contact Us</h1>
              <ol class="breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li class="active">Contact Us</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><!-- End Breadcrumbs -->




<section class="contact-us">
		 <div class="container" data-aos="fade-up">
		 <div class="section-title" data-aos="fade-up">
          <span>Contact Us</span>
          <h2>Contact Us</h2>
		  </div>
        <div class="row">
          <div class="col-md-4 col-sm-6 col-xl-4 my-3 mycard ">
      <div class="card d-block h-100 box-shadow-hover pointer">
       
        <div class="card-body p-4">
        <h4 class="h4" align="center"><a href=""> <strong>Corporate Office: </strong></a></h4>
				 <p ><i class="icofont-google-map"></i>
              108,Preet Nagar, N.H. 1,<br>
               Ambala City-134003 <br><br>
              <i class="icofont-mobile-phone"></i> +919416024794, +919982224545<br><br>
              <i class="icofont-ui-email"></i>  pritam@msmotor.in, singh@msmotor.in<br>
            </p>      </div>
      </div>
    </div>
	<div class="col-md-4 col-sm-6 col-xl-4 my-3 mycard ">
      <div class="card d-block h-100 box-shadow-hover pointer">
       
        <div class="card-body p-4">
        <h4 class="h4" align="center"><a href=""> <strong>BRANCH OFFICE:</strong></a></h4>
				 <p ><i class="icofont-google-map"></i>
              Ambala Cantt-100 The Mall <br><br>
              <i class="icofont-mobile-phone"></i> 0171-2633037, +919416024794<br><br>
              <i class="icofont-ui-email"></i>  pritam@msmotor.in, singh@msmotor.in<br>
            </p>      </div>
      </div>
    </div>
	<div class="col-md-4 col-sm-6 col-xl-4 my-3 mycard ">
      <div class="card d-block h-100 box-shadow-hover pointer">
       
        <div class="card-body p-4">
        <h4 class="h4" align="center"><a href=""> <strong>BRANCH OFFICE: </strong></a></h4>
				 <p ><i class="icofont-google-map"></i>
               Ludhiana-34/6, Nirmal Nagar, Canal Road<br><br>
              <i class="icofont-mobile-phone"></i> 0171-2633037,<br><br>
              <i class="icofont-ui-email"></i>  pritam@msmotor.in, singh@msmotor.in<br>
            </p>      </div>
      </div>
    </div>
	<div class="col-md-4 col-sm-6 col-xl-4 my-3 mycard ">
      <div class="card d-block h-100 box-shadow-hover pointer">
       
        <div class="card-body p-4">
        <h4 class="h4" align="center"><a href=""> <strong>BRANCH OFFICE: </strong></a></h4>
				 <p ><i class="icofont-google-map"></i>
               Bhadaur <br><br>
              <i class="icofont-mobile-phone"></i> 98140-56053<br><br>
              <i class="icofont-ui-email"></i>  pritam@msmotor.in, singh@msmotor.in<br>
            </p>      </div>
      </div>
    </div>
	<div class="col-md-4 col-sm-6 col-xl-4 my-3 mycard ">
      <div class="card d-block h-100 box-shadow-hover pointer">
       
        <div class="card-body p-4">
        <h4 class="h4" align="center"><a href=""> <strong>BRANCH OFFICE: </strong></a></h4>
				 <p ><i class="icofont-google-map"></i>
             Jaipur- E-8238A, VKIA Road No. 14 Tel-74278-24161

<br><br>
              <i class="icofont-mobile-phone"></i> 74278-24161<br><br>
              <i class="icofont-ui-email"></i>  pritam@msmotor.in, singh@msmotor.in<br>
            </p>      </div>
      </div>
    </div>
	<div class="col-md-4 col-sm-6 col-xl-4 my-3 mycard ">
      <div class="card d-block h-100 box-shadow-hover pointer">
       
        <div class="card-body p-4">
        <h4 class="h4" align="center"><a href=""> <strong>BRANCH OFFICE: </strong></a></h4>
				 <p ><i class="icofont-google-map"></i>
            Nathdwara
<br><br>
              <i class="icofont-mobile-phone"></i>7082201908, 7973165276<br><br>
              <i class="icofont-ui-email"></i>  pritam@msmotor.in, singh@msmotor.in ,inderjeet.msmotor@gmail.com<br>
            </p>      </div>
      </div>
    </div>
		 
         

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Contact Section ======= -->
    <div class="map-section">
	<iframe  style="border:0; width: 100%; height: 350px;"   src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1823839.521642711!2d75.80353841500978!3d29.84182553900353!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390fc902d0d575fb%3A0xbb6b98ddcdfe2c50!2sMS%20Motors!5e0!3m2!1sen!2sin!4v1593943327314!5m2!1sen!2sin"  allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
      
    </div>

    <section id="contact" class="contact">
      <div class="container">

        <div class="row justify-content-center" data-aos="fade-up">

          <div class="col-lg-10">

            <div class="info-wrap">
              <div class="row">
                <div class="col-lg-4 info">
                  <i class="icofont-google-map"></i>
                  <h4>Location:</h4>
                  <p>MS Motors 108, Preet Nagar, NH-1, <br>Ambala City-134003</p>
                </div>

                <div class="col-lg-4 info mt-4 mt-lg-0">
                  <i class="icofont-envelope"></i>
                  <h4>Email:</h4>
                  <p> pritam@msmotor.in<br> singh@msmotor.in</p>
                </div>

                <div class="col-lg-4 info mt-4 mt-lg-0">
                  <i class="icofont-phone"></i>
                  <h4>Call:</h4>
                  <p>+919416024794<br> +919982224545</p>
                </div>
              </div>
            </div>

          </div>

        </div>

        <div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-lg-10">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="form-row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                  <div class="validate"></div>
                </div>
                <div class="col-md-6 form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                  <div class="validate"></div>
                </div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                <div class="validate"></div>
              </div>
              <div class="mb-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
<?php include 'footer.php';?>

</body>

</html>