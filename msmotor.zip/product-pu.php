<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>About - MSMOTOR</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
 

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-none d-lg-block">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
       <i class="icofont-envelope"></i><a href="mailto:singh@msmotor.in">pritam@msmotor.in, singh@msmotor.in</a>
         <a href="#"><i class="icofont-phone"> </i>+919416024795,+919982224545</a>
      </div>
      <div class="social-links">
       <a href="#" class="twitter"><i class="icofont-twitter" title="Twitter"></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
   <header id="header">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>
      </div>
   <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li class="drop-down"><a href="about.php">About Us</a>
            <ul>
              <li><a href="ls.php">Leadership</a></li>
              <li ><a href="achievement.php">Achievement</a></li>
             
            </ul>
          </li>
         
         
          <li class="drop-down"><a href="#">Product</a>
            <ul>
              <li><a href="product-ap.php">Automotive paint</a></li>
              <li ><a href="product-ab.php">Abrissive</a></li>
              <li ><a href="product-cv.php">Transportation Coatings for Commercial Vehicles</a></li>
              <li ><a href="product-rb.php">Refinish Business
</a></li>
             
              <li ><a href="product-rt.php">Reflective tapes</a></li>
              <li ><a href="product-pu.php">3M PU Sealant & Double Side Tape </a></li>
              
             
            </ul>
          </li>
          <li><a href="career.php">Career</a></li>
          <li><a href="contact.php">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header>
  
  <main id="main">
	 <div id="inner_banner" class="section inner_banner_section">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="title-holder">
            <div class="title-holder-cell text-left">
              <h1 class="page-title">3M PU sealant & Double sided Tape</h1>
              <ol class="breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li class="active">3M PU sealant & Double sided Tape</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
    <!-- ======= Breadcrumbs ======= -->
   <!-- End Breadcrumbs -->

    <!-- ======= About Us Section ======= -->
    <section id="services" class="services">
      <div class="container">
	<div class="section-title" data-aos="fade-up">
          <span>  3M PU sealant & Double sided Tape


</span>
          <h2>3M PU sealant & Double sided Tape


</h2>
       </div>
	<div class="product">
        <div class="row">
		
          <div class="col-lg-6 ">
            <div class="product_content mt-5 mt-lg-0" data-aos="fade-up">
             
             
              <p>3M™ Polyurethane Sealant 540 is an all-purpose, single-component, moisture-curing, gap-filling polyurethane that creates permanently elastic seals and bonds in a wide variety of service environments. Commonly used in panel bonding and joint sealing applications. Multi-Purpose Sealant with Good UV Resistance.

</p>
            </div>
            
            
            
          </div>
          <div class="image col-lg-6 "  data-aos="fade-left" data-aos-delay="100">
			<div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">
			   <div class="carousel-inner" role="listbox">
				<?php  
		        include 'conn.php';
                $query = "SELECT * FROM product where kind ='PU'";  
                $result = mysqli_query($conn, $query);  
				$i=0;
                while($row = mysqli_fetch_array($result))  
                {  
			     if($i==0){
					 echo '<div class="carousel-item active">' ;
					  echo ' <img class="d-block w-100" src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'"  alt=""  />';
					  echo '</div>';
				 }
				 else{
					echo '<div class="carousel-item" > ';
                     echo ' <img class="d-block w-100" src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'"  alt=""  />'; 
					echo '</div>';
				}
					$i=$i+1;
				}
				
                ?>  
				 <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
      
        <span class="sr-only">Previous</span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
        
        <span class="sr-only">Next</span>
      </a>

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>
				  
			  </div>
		  
		  </div>
        </div>

      </div>
    </section>

    <!-- ======= Our Skills Section ======= -->
   

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include 'footer.php';?>

</body>

</html>