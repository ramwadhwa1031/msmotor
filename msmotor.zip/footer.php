<section class="btm-top-footer as wrapper">
	<div class="container">
		<div class="row">
	<div class="col-md-8">
	<div class="call-us">
				<h4>we provide professional consultation for free
	</h4>
	</div>
	</div>
			<div class="col-md-4">
				
				<a href="contactus.php" class=" btn hvr-icon-grow-rotate">
					contact us <i class="fa fa-phone hvr-icon"></i>
				</a>
	</div>
	</div>
	</div>
	</section>

<footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>M.S MOTOR</h3>
			<p>
				We provide higher and collaborations for the product and services of our customers and business associates in functions critical to their success. We stand to lead our business through productivity, performance, creativity, technologies and operating practice.
			</p>
			<br>
            <div class="social-links text-center text-md-left ">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
          </div>

          <div class="col-lg-2 col-md-6 footer-contact footer-links">
            <h3>Useful Links</h3>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="index.php">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.php">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="career.php">Career</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="contact.php">Contact Us</a></li>
            </ul>
				
          </div>

          <div class="col-lg-3 col-md-6 footer-contact footer-links">
            <h3>Our Services</h3>
<p><i class="icofont-address-book"></i>
              108,Preet Nagar, N.H. 1,<br>
               Ambala City-134003 <br><br>
              <i class="icofont-mobile-phone"></i>+919416024794,        +919982224545<br><br>
              <i class="icofont-ui-email"> </i> pritam@msmotor.in, singh@msmotor.in<br>
            </p>
		
          </div>

          <div class="col-lg-4 col-md-6 footer-contact footer-newsletter">
            <h3>Join Our Newsletter</h3>
            <p></p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="mr-md-auto text-center text-md-left">
        <div class="copyright">
          &copy; Copyright <strong><span>MSMOTOR</span></strong>. All Rights Reserved
        </div>
        
      </div>
     
    </div>
  </footer><!-- End Footer -->

<!-- Vendor JS Files -->


  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
 
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/jquery-sticky/jquery.sticky.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
 